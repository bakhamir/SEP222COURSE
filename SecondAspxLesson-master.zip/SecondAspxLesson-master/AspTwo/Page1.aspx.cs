﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace AspTwo
{
    public partial class Page1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["value_1"] = "hello";
            Session["value_2"] = "step";
            Response.Redirect("about.aspx");
            //Session["array"] = {"af","asf","fff" }  //;
        }

        protected void calTest_SelectionChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            datebox.Text = calTest.SelectedDate.ToShortDateString();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= 1000; i = i+5)
            {
                toBeFilled.Items.Add(i.ToString());
            }
        }

        protected void toBeFilled_SelectedIndexChanged(object sender, EventArgs e)
        {
            dropdownbox.Text = toBeFilled.SelectedValue.ToString();
        }

        protected void fillButton_Click(object sender, EventArgs e)
        {

                //TableCell c = new TableCell();
                //c.Text = "werty";
                //TableRow r = new TableRow();
                //r.Cells.Add(c);
                //tableToBeFilled.Rows.Add(r);
                //c = null; r = null;

                TableRow row = null;

            for (int i = 0; i < 100; i++)
            {
                row = new TableRow();
                for (int j = 0; j < 100; j++)
                {
                    TableCell cellitem = new TableCell();
                    cellitem.Text = " qwerrty ";
                    row.Cells.Add(cellitem);
                }
                tableToBeFilled.Controls.AddAt(i, row);
                }
        }
    }
}