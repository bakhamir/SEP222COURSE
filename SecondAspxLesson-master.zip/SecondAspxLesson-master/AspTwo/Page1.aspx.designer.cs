﻿//------------------------------------------------------------------------------
// <автоматически создаваемое>
//     Этот код создан программой.
//
//     Изменения в этом файле могут привести к неправильной работе и будут потеряны в случае
//     повторной генерации кода. 
// </автоматически создаваемое>
//------------------------------------------------------------------------------

namespace AspTwo
{


    public partial class Page1
    {

        /// <summary>
        /// Button1 элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически созданное поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button Button1;

        /// <summary>
        /// datebox элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически созданное поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox datebox;

        /// <summary>
        /// calTest элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически созданное поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Calendar calTest;

        /// <summary>
        /// Button2 элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически созданное поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button Button2;

        /// <summary>
        /// toBeFilled элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически созданное поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList toBeFilled;

        /// <summary>
        /// fill элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически созданное поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button fill;

        /// <summary>
        /// dropdownbox элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически созданное поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox dropdownbox;

        /// <summary>
        /// tableToBeFilled элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически созданное поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Table tableToBeFilled;

        /// <summary>
        /// fillButton элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически созданное поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button fillButton;
    }
}
